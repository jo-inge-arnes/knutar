R CMD BATCH build.R
cd ..
R CMD build knutar
cd knutar
