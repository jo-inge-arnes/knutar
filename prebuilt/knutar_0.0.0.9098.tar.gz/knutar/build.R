#!/usr/bin/env Rscript

library(devtools)
library(roxygen2)

document()
setwd("..")
install("knutar")
